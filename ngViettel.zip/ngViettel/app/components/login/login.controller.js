debugger;
(function() {
	'use strict';
	// Khai báo controller
	angular.module('app').controller('LoginController', LoginController);

	// Khai báo các dependencies
	LoginController.$inject=[];

	// Hàm xử lý login
	function LoginController () {
		var vm = this;

		vm.title = "Đăng nhập";
	}

})();