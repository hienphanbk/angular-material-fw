debugger;
(function() {
	'use strict';
	// Khai báo controller
	angular.module('app').controller('HomeController', HomeController);

	// Thêm các dependencies ở đây
	HomeController.$inject = [];

	// Hàm controller
	function HomeController () {
		var vm = this;
		vm.title = "Trang chủ";
	}
})();