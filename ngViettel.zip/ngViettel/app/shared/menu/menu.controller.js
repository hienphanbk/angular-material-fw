(function() {
  'use strict';
  // angular.module('app', ['ngMaterial', 'ui.router'])
  angular.module('app')
      .config(routerConfig)
      .controller('MenuController', MenuController);
      
  function MenuController($scope) {
  	var vm = this;
    vm.currentNavItem = 'home';
    console.log("You are entering home page");

    vm.doSomething = function doSomething(name) {
    	console.log("Click "+name);
    }
  }

  function routerConfig ($stateProvider, $urlRouterProvider) {
        // Các URL không khớp với bất kỳ trạng thái náo, redirect về home
        $urlRouterProvider.otherwise("/home");

        // Điều hướng
        $stateProvider
          .state('home', {
            url: "/home",
            views: {
              "view": { 
                templateUrl: "app/components/home/home.view.html",
               },
            }
          })
          .state('login', {
            url: "/login",
            views: {
              "view": { 
                templateUrl: "app/components/login/login.view.html",
                },
            }
          })
};

})();